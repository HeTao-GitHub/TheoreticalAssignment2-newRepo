package atmGUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.io.OutputStream;
import java.io.PrintStream;

//import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
//������ı�����
 class pStream extends PrintStream{
  private JTextArea jtext;
  private StringBuffer stringbuffer=new StringBuffer();
  public pStream(OutputStream out,JTextArea jtext){
	super(out);
	this.jtext=jtext;
  }
//�������Ϣ�GUI���
  public void write(byte[] buf,int off,int len){
	final String message=new String(buf,off,len);
	SwingUtilities.invokeLater(new Runnable(){
		public void run(){
			stringbuffer.append(message);
			jtext.setText(stringbuffer.toString());
		}
	});
  }
}
 //atmGUI��
public class atmGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	private ATM atm=new ATM();
	//���尴ť0~9�����룬ɾ������
	private JButton number9=new JButton(""+9);
	private JButton number8=new JButton(""+8);
	private JButton number7=new JButton(""+7);
	private JButton number6=new JButton(""+6);
	private JButton number5=new JButton(""+5);
	private JButton number4=new JButton(""+4);
	private JButton number3=new JButton(""+3);
	private JButton number2=new JButton(""+2);
	private JButton number1=new JButton(""+1);
	private JButton number0=new JButton(""+0);
	private JButton keyenter=new JButton("����");
	private JButton keydelete=new JButton("ɾ��");
	//�ı���
	private JTextArea jTextArea=new JTextArea(10,15);
	public int number=0;
	public String currentcontent="aaabcd";
	public atmGUI(){
		jTextArea.setBackground(Color.green);//�ı�����Ϊ��ɫ
		jTextArea.setLineWrap(true);//ʵ���Զ����й���
		jTextArea.setWrapStyleWord(true);//���ö��в����ֹ���
		jTextArea.setEditable(false);//��Ϊ���ɱ༭
		//�ض��嵽ͨ���ı��������������������
		System.setOut(new pStream(System.out,jTextArea));	
		//�Ѱ�ť�ӵ�panel1
		//���ּ�
		JPanel panelONE=new JPanel();
		panelONE.add(number9);
		panelONE.add(number8);
		panelONE.add(number7);
		panelONE.add(number6);
		panelONE.add(number5);
		panelONE.add(number4);
		panelONE.add(number3);
		panelONE.add(number2);
		panelONE.add(number1);
		panelONE.add(number0);
		panelONE.setBorder(new LineBorder(Color.YELLOW,2));
		panelONE.setLayout(new GridLayout(2,5));
		//���ܼ�
		JPanel panelONE2=new JPanel();
		panelONE2.add(keyenter);
		panelONE2.add(keydelete);
		panelONE2.setBorder(new LineBorder(Color.YELLOW,2));
		//panelONE2.setBackground(Color.red);
		panelONE2.setLayout(new GridLayout(2,1));
		
		//��ȡ��ǩ�ӵ�panel2
		JPanel panelTWO=new JPanel();
		panelTWO.setLayout(new GridLayout(2,0,0,0));
		JPanel panela=new JPanel(new GridLayout(2,0,0,0));
		JPanel panelb=new JPanel(new GridLayout(2,0,0,0));
		panela.setBorder(new LineBorder(Color.BLACK,2));
		panela.setBackground(Color.gray);//���������ɫ
		panelb.setBorder(new LineBorder(Color.BLACK,2));
		panelb.setBackground(Color.orange);//���������ɫ
		//����Lable  l1��l2
		JLabel l1=new JLabel();
		JLabel l2=new JLabel();
		Border lineBorder=new LineBorder(Color.RED,5);
		l1.setBorder(lineBorder);
		l2.setBorder(lineBorder);
		
		JLabel takecash =new JLabel("TAKE CASH HERE!",SwingConstants.CENTER);
		JLabel insertcard =new JLabel("INSERT DEPOSITE ENVELOPE!",SwingConstants.CENTER);
		panela.add(takecash);		
		panela.add(l1);
		panelb.add(insertcard);
		panelb.add(l2);
		panelTWO.add(panela);
		panelTWO.add(panelb);
		//�ı���ӵ�panel3
		JPanel panel3 =new JPanel();
		jTextArea.setSize(200,200 );
		panel3.add(jTextArea);
		//�������ּ��ʹ�ȡ��panel4
		JPanel panel4=new JPanel();
		panel4.add(panelONE,BorderLayout.NORTH);
		panel4.add(panelONE2,BorderLayout.SOUTH);
		panel4.add(panelTWO, BorderLayout.EAST);
		add(new JScrollPane(jTextArea),BorderLayout.CENTER);
		//�����������ӵ�frame
		add(panel3,BorderLayout.NORTH);
		add(panel4,BorderLayout.SOUTH);
		//���Ӽ�����
		ButtonListener listener=new ButtonListener();
		number9.addActionListener(listener);
		number8.addActionListener(listener);
		number7.addActionListener(listener);
		number6.addActionListener(listener);
		number5.addActionListener(listener);
		number4.addActionListener(listener);
		number3.addActionListener(listener);
		number2.addActionListener(listener);
		number1.addActionListener(listener);
		number0.addActionListener(listener);
		keyenter.addActionListener(listener);
		keydelete.addActionListener(listener);
	}//���캯��
	class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			//int number=0;
			e.getSource();
			if(e.getSource()==number0){ number=number*10;jTextArea.append("0");}
			else if(e.getSource()==number1){ number=number*10+1;jTextArea.append("1");}
			else if(e.getSource()==number2){ number=number*10+2;jTextArea.append("2");}
			else if(e.getSource()==number3){ number=number*10+3;jTextArea.append("3");}
			else if(e.getSource()==number4){ number=number*10+4;jTextArea.append("4");}
			else if(e.getSource()==number5){ number=number*10+5;jTextArea.append("5");}
			else if(e.getSource()==number6){ number=number*10+6;jTextArea.append("6");}
			else if(e.getSource()==number7){ number=number*10+7;jTextArea.append("7");}
			else if(e.getSource()==number8){ number=number*10+8;jTextArea.append("8");}
			else if(e.getSource()==number9){ number=number*10+9;jTextArea.append("9");}
			else if(e.getSource()==keyenter){
				atm.keypad.input=number;	
				atm.keypad.run=1;
				number=0;
			}
			else if(e.getSource()==keydelete){
				currentcontent=jTextArea.getText();
				currentcontent=currentcontent.substring(0,currentcontent.length()-1);
				jTextArea.setText(currentcontent);
				number=number/10;
				
			}
		}
	}

   public static void main( String[] args ){
	   //����ATM����
		atmGUI testATM=new atmGUI();
		testATM.setTitle("atmGUI");
		testATM.pack();
		testATM.setLocationRelativeTo(null);
		testATM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		testATM.setVisible(true);
		testATM.setBackground(Color.green);
		testATM.atm.run();
   }
}