package atmGUI;//import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
	public int run;
 public  int input;
// public Keypad()
 //{
 //} // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 for(run=0;run==0;)
		 System.out.print("");
    return input;// we assume that user enters an integer
 } // end method getInput
 }